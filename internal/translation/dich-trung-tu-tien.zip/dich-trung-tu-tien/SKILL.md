---
name: dich-trung-tu-tien
description: Dịch tiếng Trung sang tiếng Việt cho phim, kịch bản, phụ đề và voice script, đặc biệt là tiên hiệp, tu tiên, huyền huyễn, võ hiệp và cổ trang. Dùng khi cần dịch SRT hoặc thoại Trung–Việt tự nhiên, đúng lore và thuật ngữ cảnh giới, tông môn, pháp bảo, nhân xưng, có cảm xúc như người dịch thật, đồng thời có thể pha chút cách nói Gen Z đúng chỗ mà không phá chất cổ phong.
---

# Dịch Trung tu tiên

## Mục tiêu

Tạo bản dịch tiếng Việt:

- đúng nghĩa, đúng quan hệ nhân vật và đúng diễn biến;
- có giọng nói, nhịp cảm xúc và ẩn ý, không giống bản dịch máy;
- giữ chất tiên hiệp/cổ phong khi bối cảnh yêu cầu;
- dùng từ Việt tự nhiên, dễ nghe khi lồng tiếng;
- bảo toàn định dạng SRT, bảng thoại hoặc cấu trúc file nguồn.

Không áp một bảng cảnh giới cố định cho mọi tác phẩm. Hãy dựng sổ thuật ngữ riêng cho từng phim trước khi dịch hàng loạt.

## Quy trình bắt buộc

### 1. Đọc và phân loại nguồn

Xác định trước:

1. Thể loại: tiên hiệp, tu tiên, huyền huyễn, võ hiệp, cổ trang, hiện đại tu chân hay pha trộn.
2. Bối cảnh: cổ đại, hiện đại, tiên giới, phàm giới, ma giới, cung đình, tông môn hoặc đời thường.
3. Người nói, người nghe, tuổi tác, địa vị, quan hệ và mức độ thân–sơ.
4. Hệ thống cảnh giới, tên riêng, tước vị, môn phái, vật phẩm, giới vực và cách gọi lặp lại.
5. Mục đích đầu ra: phụ đề đọc nhanh, thoại lồng tiếng, bản văn học hay bản sát nghĩa để đối chiếu.

Nếu thiếu ngữ cảnh, dịch theo bằng chứng có trong đoạn và đánh dấu phần mơ hồ trong ghi chú, không tự bịa. Với một file dài, lập một bảng nhất quán gồm: `中文 | Hán-Việt/tiếng Việt chọn dùng | nghĩa trong phim | ghi chú quan hệ`.

Với phim dài, đọc toàn bộ file trước khi dịch hàng loạt. Lập thêm bốn bản đồ riêng: `nhân vật–xưng hô`, `cảnh giới lớn–cảnh giới nhỏ`, `giới vực–khu vực đặc biệt`, `tước hiệu–chức vụ`. Không suy ra hệ thống của phim chỉ từ vài câu đầu.

### 2. Khóa thuật ngữ trước khi dịch tiếp

Tra cứu [bảng thuật ngữ tu tiên](references/tu-tien-glossary.md), sau đó ưu tiên thuật ngữ đã xuất hiện trong chính tác phẩm. Phân biệt rõ:

- **cảnh giới** với **trạng thái/động tác**: `结丹`, `渡劫`, `婴变`, `问鼎` có thể là quá trình hoặc tên cấp tùy tác phẩm; `金丹`, `元婴` có thể là cảnh giới hoặc thực thể;
- **tu vi** với **cảnh giới**: `修为` thường là tu vi, `境界` là cảnh giới;
- **pháp bảo, linh khí, tiên khí** với nhau;
- **sư tôn, sư phụ, trưởng lão, chưởng môn, tông chủ**;
- **yêu, ma, quỷ, linh thú** nếu lore của phim phân biệt chúng.

Mỗi mục phải được ghi theo dạng `mặc định | điều kiện kích hoạt | cấm suy diễn`. Không biến bản dịch thường gặp thành luật bắt buộc. Nếu chưa biết một từ là cảnh giới, tước hiệu, chức vụ, khu vực, chủng tộc, trạng thái hay vật thể thì để trạng thái `chưa xác nhận` trong sổ nội bộ.

Không đổi thuật ngữ giữa các câu chỉ vì muốn tránh lặp. Chỉ đổi khi ngữ cảnh hoặc cấp độ nghĩa thực sự khác.

### 3. Dịch theo ý định và cảm xúc

Trước mỗi câu, trả lời thầm ba câu hỏi: nhân vật muốn làm gì, đang che giấu hay nhấn mạnh điều gì, và người nghe cần cảm nhận được thái độ nào?

- Dịch **hiệu ứng câu nói**, không bê nguyên trật tự tiếng Trung.
- Giữ câu ngắn, nhịp rõ, dễ đọc thành tiếng; câu giận dữ có thể gọn và sắc, câu đau lòng có thể đứt nhịp, câu đe dọa phải có lực.
- Không biến mọi nhân vật thành cùng một giọng. Nhân vật lạnh lùng, hoạt bát, kiêu ngạo, quân tử, mưu mô và bi thương phải khác nhau.
- Giữ sự tiết chế của cổ phong trong lời dẫn và các cảnh nghiêm túc; không chèn slang chỉ để “trẻ hóa”.
- Với tiếng cười, tiếng thở, tiếng ngập ngừng và hạt tình thái (`啊`, `呀`, `呢`, `吧`, `哼`, `呵`), chỉ chuyển khi chúng mang sắc thái. Không dịch máy móc từng hạt.
- Thành ngữ, ẩn dụ và câu châm biếm phải được Việt hóa theo tác dụng; nếu hình ảnh gốc là mấu chốt lore thì giữ hình ảnh và làm câu tự nhiên.

### 4. Chọn nhân xưng có hệ thống

Dùng ma trận quan hệ, không chọn “ta–ngươi” cho tất cả. Mặc định tham khảo:

- thân mật hiện đại: `tôi–cậu`, `tôi–anh/chị`, `mình–cậu`;
- cổ trang trung tính: `ta–ngươi`, `ta–nàng/chàng`, nhưng chỉ dùng khi hợp địa vị và sắc thái;
- sư môn: `sư tôn–đệ tử`, `sư huynh/sư tỷ–sư đệ/sư muội`;
- giang hồ: `tại hạ`, `các hạ`, `đạo hữu`, `tiền bối`, `vãn bối`;
- cung đình: `bệ hạ`, `điện hạ`, `nương nương`, `vương gia`, `đại nhân`, `bổn cung`, `bổn vương`, `bổn tọa`;
- nữ giới và gia đình: `thiếp`, `nô tỳ`, `phu quân`, `phu nhân`, `mẫu thân`, `phụ thân` khi địa vị/cổ phong yêu cầu.

Nhân xưng có thể đổi theo diễn biến quan hệ. Khi nhân vật chuyển từ kính trọng sang phản bội, hoặc từ xa cách sang yêu đương, cho phép xưng hô thay đổi có chủ ý và ghi lại trong sổ thuật ngữ. Các dòng tham khảo trên chỉ là ứng viên, không được tự động gán theo chức vị: chưởng môn chưa chắc dùng `bổn tọa`, nữ cường giả chưa chắc dùng `bổn cung`, trưởng lão chưa chắc dùng `lão phu`, và Tiên Đế chưa chắc dùng `trẫm`.

### 5. Phân biệt cảnh giới, tước hiệu và giới vực

Đọc [hướng dẫn xưng hô nâng cao](references/forms-of-address.md) và [hướng dẫn hệ thống cảnh giới–giới vực](references/world-systems.md) khi nguồn có nhiều tầng quyền lực hoặc worldbuilding phức tạp.

- Tách **đại cảnh giới**, **tiểu cảnh giới**, **cấp phẩm**, **cấp chiến lực** và **tước hiệu**. `化神后期` là “Hóa Thần hậu kỳ”, còn `半步化神` là “bán bộ Hóa Thần”, không tự đổi thành một cảnh giới mới.
- Giữ nguyên quan hệ giữa số tầng và tên cấp: `一重/九重`, `一层/十三层`, `一品/九品`, `一阶/九阶`, `初期/中期/后期/巅峰/圆满/大圆满` không được trộn lẫn nếu phim phân biệt. `一品`, `一阶` và `一层` có thể là cấp cảnh giới trong một số tác phẩm, không được cấm chúng chỉ vì thường gặp ở vật phẩm hoặc Luyện Khí.
- Phân biệt **cấp tu luyện** với **tước hiệu có chữ 尊/帝/君/神/圣**. `仙尊`, `魔尊`, `帝君`, `上神`, `圣主` có thể là danh hiệu địa vị, không mặc định là cảnh giới.
- Không áp một thứ tự cố định như `真仙 → 天仙 → 玄仙 → 金仙 → 太乙 → 大罗`, cũng không tự suy ra `大乘` luôn đứng sau hay trước `渡劫`; phải ghi thứ tự đúng theo tác phẩm.
- Phân biệt **giới vực** với **địa điểm** và **khu vực cấm**: `仙界`, `魔界`, `界海`, `秘境`, `禁地`, `圣地`, `洞天福地`, `遗迹`, `虚空` không dịch cùng một kiểu chỉ vì đều là nơi chốn.
- Phân biệt chủng tộc/lập trường: `妖`, `魔`, `鬼`, `灵`, `神`, `仙` có thể là loài, phe phái, trạng thái hoặc danh hiệu tùy lore; không tự gom thành “quái vật” hay “yêu ma”.

### 6. Xác định thế giới và khu vực

`人界/凡界/下界`, `上界/仙界`, `鬼界/冥界`, `洞府/洞天/福地`, `秘境/禁地/禁区/绝地/圣地` có thể chồng lấn hoặc tách biệt. Hậu tố `界/域/地/海/天/宫/殿/府/门` chỉ là dấu hiệu tham khảo. Không mặc định `界海` là biển thật hay không phải biển thật, `九重天` là chín tầng theo nghĩa vật lý, `绝地` là chắc chắn chết, hoặc `门/宗` luôn là tổ chức.

### 7. Điều chỉnh mức Gen Z

Gen Z chỉ là lớp gia vị của tiếng Việt, không phải thay toàn bộ phong cách. Ưu tiên cách nói tự nhiên như `thôi xong`, `đúng là hết nói nổi`, `đừng có mơ`, `chơi lớn đấy`, `không ổn rồi`, `đỉnh thật` khi nhân vật và bối cảnh cho phép.

Tránh meme ngắn hạn, tiếng lóng quá mạng, từ thô tục không có trong nguyên tác, hoặc câu hiện đại làm vỡ cảnh cung đình/tu luyện. Cảnh bi thương, sinh tử, sư đồ, thề ước và đối đầu cấp cao phải giữ lực cổ phong; chỉ dùng Gen Z ở cảnh đời thường, nhân vật hài, hoặc khi bản gốc có ý châm biếm rõ.

### 8. Bảo toàn định dạng

Với SRT:

- giữ nguyên số thứ tự và mốc thời gian;
- không gộp, tách, xáo trộn hoặc bỏ block;
- không chèn giải thích vào dòng phụ đề;
- giữ số dòng vừa đủ để đọc, ưu tiên câu ngắn và ngắt tự nhiên;
- không áp một giới hạn ký tự cứng cho mọi dự án; ưu tiên thời lượng hiển thị, tốc độ thoại, font và khả năng đọc thực tế;
- giữ dấu câu tiếng Việt nhất quán; tránh dấu chấm làm TTS ngắt quá dài nếu đầu ra dùng cho voice.

Với bảng hoặc script voice:

- giữ nguyên tên cột, thứ tự dòng, mã câu và trường dữ liệu;
- chỉ thay phần cần dịch, trừ khi người dùng yêu cầu sửa cấu trúc;
- không tự thêm câu dẫn, lời giải thích hay đáp án vào file;
- nếu câu quá dài cho voice, cung cấp bản dịch đã chia nhịp nhưng không làm mất ý.

## Quy tắc tên riêng và văn hóa

- Với phim cổ trang, tiên hiệp, tu tiên và huyền huyễn Trung Quốc, mặc định dùng **âm Hán–Việt chuẩn** cho tên nhân vật: `白子画 → Bạch Tử Họa`, `花千骨 → Hoa Thiên Cốt`, `李长生 → Lý Trường Sinh`. Không tự chuyển sang pinyin kiểu `Bai Zihua` nếu dự án đã chọn Hán–Việt.
- Tên chính thức do người dùng, nhà phát hành, bản phim hoặc phụ đề gốc cung cấp luôn được ưu tiên hơn mặc định Hán–Việt. Nếu tác phẩm đã có bản Việt hóa nổi tiếng, ghi cách đó vào sổ tên và dùng thống nhất.
- Phân biệt **họ tên**, **tên tự/hiệu**, **bí danh**, **tôn hiệu**, **chức vụ** và **cách gọi quan hệ**. Ví dụ `Diệp Thanh` có thể là tên; `Diệp tông chủ` là họ + chức vụ; `Tiên Tôn` có thể là tôn hiệu, không tự coi là tên thật.
- Khi nhân vật xuất hiện lần đầu, ghi sổ: `chữ Hán | âm Hán–Việt | tên dùng trong thoại | bí danh/tước hiệu | giới tính nếu cần | quan hệ`. Không để cùng một nhân vật có hai cách đọc ở các block khác nhau.
- Không dịch nghĩa tên riêng thành tên Việt tùy ý, không tự đổi tên để “nghe hay hơn”, không thêm họ hoặc bỏ chữ trong tên nếu chưa có căn cứ.
- Tên hiện đại, thương hiệu, địa chỉ, câu tiếng Anh hoặc tên đã được tác phẩm Việt hóa thì giữ theo ngữ cảnh; không áp âm Hán–Việt cho tên hiện đại chỉ vì chữ Hán.
- Kiểm tra chữ Hán đầy đủ trước khi chốt âm đọc. Đặc biệt chú ý chữ đa âm, tên có thể đọc theo âm Hán–Việt khác nhau, và tên giống thuật ngữ cảnh giới hoặc địa danh.
- Trong lời thoại, dùng tên đầy đủ khi giới thiệu, gọi trang trọng hoặc cần phân biệt; dùng tên riêng, tên thân mật, họ + chức danh hoặc tước hiệu theo đúng quan hệ. Không thay tên bằng tước hiệu chỉ để tránh lặp.
- Tên nhân vật nữ, nam, yêu tộc, ma tộc, thần tộc vẫn giữ nguyên cách đọc Hán–Việt; không Việt hóa thành tên đời thường và không suy giới tính chỉ từ một chữ tên mơ hồ.
- Nếu chưa xác định được đây là tên người hay danh hiệu, giữ chữ Hán trong sổ nội bộ và ghi `[CẦN XÁC NHẬN]`; không đoán rồi để sai xuyên suốt bản dịch.
- Không biến thuật ngữ Phật giáo, Đạo giáo, y học cổ truyền hoặc điển cố thành từ hiện đại sơ sài nếu nó có vai trò trong thế giới truyện.

Khi xử lý nhiều nhân vật hoặc tên có nhiều cách gọi, đọc thêm [quy tắc tên nhân vật](references/character-names.md) trước khi khóa bản dịch.

## Kiểm tra trước khi giao

Đọc lại bản dịch như một người xem Việt Nam, rồi kiểm tra:

1. Có sai chủ thể, phủ định, thời gian, số lượng, nguyên nhân–kết quả hoặc quan hệ nhân vật không?
2. Nhân xưng và kính ngữ có khớp từng cảnh không?
3. Cảnh giới, tên riêng, tông môn, pháp bảo và cấp bậc có nhất quán không?
4. Câu có tự nhiên khi đọc thành tiếng không, có bị Hán-Việt hóa cứng hoặc hiện đại hóa quá tay không?
5. Cảm xúc, mỉa mai, đe dọa, yêu thương, đau đớn và hài hước có còn nguyên lực không?
6. Có câu nào vô tình tiết lộ thông tin mà nguyên tác chưa tiết lộ không?
7. File có còn nguyên cấu trúc, số block, timestamp và mã dòng không?
8. Các ghi chú `[CẦN XÁC NHẬN]` chỉ nằm trong sổ nội bộ, không chèn vào SRT thành phẩm nếu người dùng không yêu cầu.

Khi người dùng yêu cầu “dịch tự nhiên”, ưu tiên bản dịch có hồn nhưng không được tự ý đổi cốt truyện. Khi người dùng yêu cầu “sát nghĩa”, giảm mức Việt hóa và Gen Z, nhưng vẫn sửa ngữ pháp để tiếng Việt không cứng.

## Cách trả kết quả

Nếu người dùng đưa đoạn ngắn, trả bản dịch ngay và chỉ thêm ghi chú khi có điểm mơ hồ ảnh hưởng nghĩa. Nếu người dùng đưa file, xử lý toàn bộ theo đúng cấu trúc file và báo ngắn gọn các thuật ngữ đã khóa hoặc chỗ cần xác nhận. Không trả lời bằng phân tích dài thay cho bản dịch.

Đọc [hướng dẫn thoại và kiểm âm](references/dialogue-voice.md) khi đầu ra là phụ đề phim hoặc voice script. Đọc [bảng thuật ngữ tu tiên](references/tu-tien-glossary.md) khi gặp thuật ngữ nền. Đọc [hướng dẫn xưng hô nâng cao](references/forms-of-address.md) và [hướng dẫn hệ thống cảnh giới–giới vực](references/world-systems.md) trước khi xử lý phim có nhiều tông phái, triều đình, tiên–ma–thần–yêu hoặc nhiều tầng thế giới. Đọc [quy tắc thẩm định nghiên cứu](references/research-audit.md) khi có bảng thuật ngữ do AI, nguồn ngoài hoặc người dùng cung cấp. Khi gặp dữ liệu AI dài, ưu tiên lọc thành quy tắc có điều kiện trước khi nhập vào glossary; không chép nguyên bảng nghiên cứu vào bản dịch.
