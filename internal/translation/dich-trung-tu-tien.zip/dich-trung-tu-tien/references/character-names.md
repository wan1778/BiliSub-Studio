# Quy tắc dịch tên nhân vật Trung–Việt

## 1. Nguyên tắc ưu tiên

Thứ tự ưu tiên khi chốt tên:

1. Cách viết chính thức do người dùng, nhà phát hành, bản phim hoặc phụ đề chuẩn cung cấp.
2. Cách gọi đã được tác phẩm dùng ổn định trong lời thoại, phụ đề, poster hoặc danh sách nhân vật.
3. Âm Hán–Việt chuẩn, phù hợp bối cảnh cổ trang, tiên hiệp, tu tiên và huyền huyễn.
4. Pinyin hoặc phiên âm khác chỉ dùng khi nguồn chính thức yêu cầu, tên hiện đại cần giữ nguyên, hoặc dự án đã chọn hệ đó từ đầu.

Không trộn Hán–Việt với pinyin trong cùng một tác phẩm nếu không có lý do rõ ràng. Một khi đã khóa tên, mọi block SRT, bảng nhân vật và voice script phải dùng cùng một cách viết.

Pinyin có thể ghi trong **cột đối chiếu nội bộ** để tra chữ Hán và kiểm tra phát âm, nhưng không tự đưa pinyin vào phụ đề. Chỉ dùng pinyin trong đầu ra khi người dùng, nhà phát hành hoặc quy ước chính thức của dự án yêu cầu.

## 2. Tên cổ trang, tiên hiệp và huyền huyễn

Tên người Trung Quốc trong bối cảnh cổ phong mặc định đọc theo âm Hán–Việt:

| Chữ Hán | Tên dùng | Ghi chú |
|---|---|---|
| 白子画 | Bạch Tử Họa | Tên người, không tách thành “Bạch” và “Tử Họa” tùy ý |
| 花千骨 | Hoa Thiên Cốt | Giữ nguyên tên tác phẩm đã quen dùng |
| 李长生 | Lý Trường Sinh | Không dịch nghĩa thành “Lý Sống Lâu” |
| 叶孤城 | Diệp Cô Thành | `孤` trong tên riêng đọc theo tên, không dịch thành “cô vương” |
| 东方月初 | Đông Phương Nguyệt Sơ | Họ kép `东方` phải giữ đủ |

Không Việt hóa tên thành tên đời thường như “Anh”, “Linh”, “Minh” và không dịch nghĩa tên riêng thành một tên mới. Tên có ý nghĩa biểu tượng vẫn giữ âm tên; chỉ giải thích ý nghĩa khi người dùng yêu cầu.

## 3. Phân biệt tên và danh xưng

Trước khi dịch phải phân loại từng cụm:

| Loại | Ví dụ | Cách xử lý |
|---|---|---|
| Tên thật | 白子画 | Bạch Tử Họa |
| Họ + tên | 萧炎 | Tiêu Viêm |
| Họ kép | 东方月初 | Đông Phương Nguyệt Sơ |
| Tên tự/hiệu | 无名, 青莲居士 | Dịch hoặc giữ theo chức năng của hiệu, không nhập vào tên thật |
| Bí danh | 夜尊, 无心 | Ghi riêng là bí danh; không tạo nhân vật mới |
| Tước hiệu | 仙尊, 魔尊, 帝君 | Dịch thành Tiên Tôn, Ma Tôn, Đế Quân nếu là tước hiệu |
| Chức vụ | 宗主, 掌门, 长老 | Tông chủ, Chưởng môn, Trưởng lão; không coi là tên |
| Họ + chức vụ | 叶宗主 | Diệp tông chủ, không phải tên “Diệp Tông Chủ” |
| Tên gọi quan hệ | 师尊, 师父, 前辈 | Sư tôn, sư phụ, tiền bối; không thay bằng tên riêng |

`尊上`, `仙尊`, `魔尊`, `神尊`, `帝君`, `圣主` có thể là tước hiệu hoặc tên gọi thay thế tên thật. Chỉ viết hoa như tên riêng khi tác phẩm dùng nó như danh xưng độc lập của một nhân vật; nếu chỉ là danh từ chung thì viết thường theo quy tắc của dự án.

Phân biệt ba trường hợp:

- **Tôn hiệu/chức vụ**: nhiều người có thể dùng hoặc thay đổi theo thân phận, như `宗主`, `仙尊`, `圣主`.
- **Cách gọi cố định trong tác phẩm**: một nhân vật có thể luôn được gọi là `尊上` hoặc `师尊`, nhưng đây vẫn là cách gọi/tôn xưng, không mặc nhiên là tên thật.
- **Tên riêng độc lập**: chỉ xác nhận khi lời thoại, danh sách nhân vật hoặc lore dùng danh xưng đó như định danh duy nhất của nhân vật.

`本尊` thường là tự xưng hoặc chỉ chân thân đối lập với phân thân, không xử lý như tên người chỉ vì nó lặp lại. Tuy nhiên, mọi trường hợp vẫn phải xem ngữ pháp và quy ước riêng của tác phẩm; không dùng câu “không bao giờ” làm luật chung.

## 4. Bí danh, phân thân và cùng một nhân vật

Một nhân vật có thể có nhiều tên do cải trang, chuyển thế, đoạt xá, phân thân hoặc đổi thân phận. Không tạo thành nhiều nhân vật chỉ vì tên khác nhau.

Sổ nội bộ phải ghi:

```text
Tên gốc: __________________
Âm Hán–Việt: __________________
Tên dùng hiện tại: __________________
Bí danh/tên cũ: __________________
Tước hiệu/chức vụ: __________________
Phân thân/chân thân: __________________
Quan hệ với nhân vật khác: __________________
```

Nếu câu thoại cố ý giấu thân phận, vẫn dịch đúng tên đang được gọi trong cảnh đó; không tự tiết lộ tên thật trong phụ đề.

## 5. Cách gọi tên theo quan hệ

Tên dùng trong thoại thay đổi theo khoảng cách và quyền lực:

- Giới thiệu trang trọng: dùng họ tên hoặc tên đầy đủ.
- Người ngoài gọi: có thể dùng họ + chức vụ, tước hiệu hoặc `công tử/cô nương`.
- Sư môn: dùng `sư huynh`, `sư tỷ`, `sư tôn`, `sư phụ` thay cho tên khi quan hệ là trọng tâm.
- Người yêu, đạo lữ hoặc người thân: có thể dùng tên riêng, tên thân mật hoặc tên tự nếu nguyên tác thể hiện sự thân mật.
- Cung đình và thế lực: dùng chức tước khi nghi lễ hoặc quyền lực được nhấn mạnh.
- Cảnh xung đột: đối phương có thể cố ý gọi tên thật thay vì tước hiệu để hạ nhục, hoặc gọi tước hiệu để mỉa mai; phải giữ dụng ý đó.

Không đổi tên thành tước hiệu chỉ vì câu bị lặp. Nếu nguyên tác lặp tên để tạo nhịp cảm xúc, giữ tên; nếu lặp do tiếng Trung thường lược chủ ngữ, có thể bỏ tên trong tiếng Việt khi không làm mất chủ thể.

Khi một nhân vật có nhiều cách gọi, ưu tiên theo **tên đang được dùng trong cảnh**: tên giả nếu đang che giấu thân phận, tước hiệu/chức vụ nếu nghi lễ hoặc thế lực được nhấn mạnh, biệt danh nếu lời thoại nói về danh tiếng, và bản danh khi giới thiệu hoặc vạch trần thân phận. Đây là thứ tự xử lý phụ đề, không phải thứ bậc cố định của nhân vật.

Ví dụ: nếu một người đang sống dưới tên giả `Mạc Huyền Vũ`, phụ đề giữ “Mạc Huyền Vũ” cho đến khi cốt truyện cho phép lộ thân phận thật. Bảng nhân vật nội bộ mới liên kết tên giả với bản danh; không được tiết lộ bí mật bằng cách tự đổi tên sớm.

## 6. Tên hiện đại và tác phẩm pha trộn

- Phim hiện đại Trung Quốc: thường giữ cách viết Latin/pinyin hoặc cách Việt hóa chính thức của dự án.
- Phim xuyên không: nhân vật hiện đại có thể giữ tên hiện đại; khi vào bối cảnh cổ phong, tên nhân vật bản địa vẫn đọc Hán–Việt.
- Tác phẩm pha hiện đại–cổ đại: không đổi toàn bộ tên chỉ vì một vài cảnh dùng tiếng hiện đại.
- Tên nước ngoài, thương hiệu, game ID hoặc nickname: giữ nguyên nếu nguồn đã dùng Latin; không tự chuyển thành Hán–Việt.

Tiền tố hoặc hậu tố thân mật như `阿`, `小`, `老`, `儿/兒` phải xét chức năng: `阿羡 → A Tiện`, `小白 → Tiểu Bạch`, `琴儿 → Cầm Nhi` có thể là cách gọi thân mật, không nhất thiết là một phần của bản danh. Không tự dịch thành “con”, “bé” hoặc bỏ đi nếu nó thể hiện quan hệ.

Nếu dự án chọn pinyin cho tên hiện đại, phải ghi rõ trong sổ thuật ngữ và không chuyển qua lại giữa `Li Changsheng`, `Lý Trường Sinh` hoặc cách khác.

## 7. Lỗi OCR, phụ đề và chữ đa âm

Trước khi chốt tên, đối chiếu ít nhất hai lần xuất hiện nếu có thể. Cẩn thận với:

- chữ OCR gần giống nhau làm đổi tên;
- tên bị thiếu một chữ ở phụ đề;
- tên bị dính với chức vụ, trợ từ hoặc dấu câu;
- chữ có nhiều âm Hán–Việt;
- họ kép như `欧阳`, `司马`, `诸葛`, `东方`, `慕容`; không nhầm chúng với hai từ độc lập hoặc một địa danh;
- tên giống cảnh giới, pháp bảo, tông môn hoặc địa danh.

Không đoán âm chỉ từ pinyin máy dịch hoặc phụ đề lỗi. Nếu chưa đủ bằng chứng, dùng bản ghi nội bộ `chữ Hán | cách đọc nghi vấn | vị trí xuất hiện | phương án chờ xác nhận`; không đưa ghi chú này vào SRT thành phẩm.

## 8. Kiểm tra tên trước khi xuất SRT

Trước khi giao bản dịch, kiểm tra:

1. Một nhân vật có bị đổi cách viết giữa các block không?
2. Tên thật có bị nhầm với tước hiệu, chức vụ hoặc tên địa danh không?
3. Họ kép có bị tách sai không?
4. Có vô tình dịch nghĩa tên riêng thành tên Việt mới không?
5. Tên bị che giấu trong nguyên tác có bị tiết lộ sớm không?
6. Cách gọi có đúng quan hệ và mức độ thân–sơ trong cảnh đó không?
7. Tên trong thoại, bảng nhân vật và voice script có giống nhau không?
8. Có `[CẦN XÁC NHẬN]`, chú giải hoặc phân tích lọt vào phụ đề không?

## 9. Mẫu bảng khóa tên

```text
| Chữ Hán | Âm Hán–Việt/tên chính thức | Loại | Bí danh | Tước hiệu/chức vụ | Cách gọi theo quan hệ | Ghi chú |
|---------|----------------------------|------|---------|-------------------|-----------------------|---------|
|         |                            |      |         |                   |                       |         |
```

Tên chưa chắc chắn phải được đánh dấu trong bảng nội bộ và xử lý sau khi có thêm ngữ cảnh. Tuyệt đối không tùy tiện chọn một cách đọc chỉ để hoàn thành nhanh bản dịch.
