# Hướng dẫn dịch thoại và kiểm âm

## Nhịp câu

- Phụ đề phải đọc kịp; ưu tiên một ý chính mỗi câu.
- Voice script phải nghe như người đang nói, không như văn bản dịch.
- Tách câu ở nơi người nói thực sự lấy hơi, đổi ý hoặc nhấn mạnh.
- Không dùng quá nhiều dấu chấm lửng; chỉ dùng khi có ngập ngừng, đứt quãng hoặc bỏ lửng có chủ ý.
- Dùng dấu phẩy để tạo nhịp ngắn trong câu voice; tránh chuỗi mệnh đề dài.
- Không áp một giới hạn ký tự cứng cho mọi file SRT. Khi kiểm phụ đề, cân đối độ dài với timestamp, tốc độ đọc, kích thước chữ và số dòng; chỉ dùng giới hạn dự án nếu người dùng đã quy định.

## Chuyển cảm xúc

| Ý định gốc | Hướng xử lý tiếng Việt |
|---|---|
| 威胁 | câu ngắn, động từ mạnh, không thêm lời giải thích |
| 讽刺 | giữ độ cay; có thể Việt hóa thành câu châm biếm tự nhiên |
| 撒娇 | mềm hơn, có thể dùng “mà”, “đấy”, “nhé” nếu hợp nhân vật |
| 悲痛 | giảm chữ, để khoảng lặng nằm trong nhịp câu |
| 震惊 | dùng “Cái gì?”, “Không thể nào…”, “Sao có thể?” theo mức độ |
| kính trọng | giữ danh xưng và cấu trúc nhún nhường; không cần làm mọi câu quá cổ |
| hài hước | cho phép một chút cách nói hiện đại/Gen Z, nhưng không dùng meme chóng lỗi thời |

## Các lỗi phải tránh

- Dịch `你` thành “ngươi” ở mọi dòng.
- Dịch `我` thành “ta” ở cả bối cảnh hiện đại.
- Tự thêm “bổn tọa”, “bổn vương”, “bổn cung” chỉ vì đoán người nói có địa vị; phải kiểm tra nguyên tác đã dùng cách tự xưng đó hay chưa.
- Dịch từng chữ thành câu vô hồn: `你找死` không nhất thiết là “ngươi tìm chết”, có thể là “Muốn chết à?” hoặc “Ngươi chán sống rồi sao?” tùy quan hệ.
- Lặp nguyên một cấu trúc Trung Quốc khiến tiếng Việt cứng.
- Dịch tiếng cười, tiếng thở, hạt tình thái và lời đệm thành các từ thừa làm thoại giả.
- Thêm cảm xúc mà nguyên tác không có hoặc làm nhẹ một câu vốn là lời tuyên chiến.

## Mẫu chuyển câu theo ngữ cảnh

Các câu dưới đây chỉ minh họa cách suy theo ý định, không phải bản dịch cố định:

| 中文 | Cứng/không nên dùng | Có thể dùng |
|---|---|---|
| 你找死吗？ | Ngươi tìm chết sao? | Muốn chết à? / Ngươi chán sống rồi sao? |
| 休想！ | Đừng nghĩ! | Đừng hòng! |
| 我看谁敢动她 | Ta xem ai dám động nàng | Để ta xem kẻ nào dám đụng đến cô ấy |
| 你可真有本事 | Ngươi thật sự có bản lĩnh | Cậu giỏi quá ha. / Đúng là tài thật đấy. |
| 这下麻烦了 | Lần này phiền phức rồi | Thôi xong rồi. / Lần này rắc rối to rồi. |

Chọn câu cuối dựa trên bối cảnh, địa vị và sắc thái chứ không lấy một mẫu cho mọi nhân vật.

## Kiểm âm cuối cùng

Đọc thành tiếng hoặc tự hình dung giọng đọc:

1. Có câu nào dài đến mức phải lấy hơi giữa từ quan trọng không?
2. Dấu câu có khiến TTS ngắt quá lâu hoặc ngắt sai ý không?
3. Phụ âm, đại từ và tên riêng có dễ phát âm không?
4. Câu thoại có giống lời người Việt nói trong cảm xúc đó không?
5. Khi đọc nhanh, ý chính và từ khóa cảm xúc có còn nổi bật không?
