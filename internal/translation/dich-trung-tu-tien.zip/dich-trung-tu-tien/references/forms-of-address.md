# Hệ thống xưng hô và tước hiệu nâng cao

## Mục lục

- [Nguyên tắc đọc xưng hô](#nguyên-tắc-đọc-xưng-hô)
- [Tự xưng theo thân phận](#tự-xưng-theo-thân-phận)
- [Gọi người khác theo quan hệ](#gọi-người-khác-theo-quan-hệ)
- [Sư môn và giang hồ](#sư-môn-và-giang-hồ)
- [Triều đình và phủ đệ](#triều-đình-và-phủ-đệ)
- [Đạo môn, Phật môn, tiên–ma–yêu](#đạo-môn-phật-môn-tiênma-yêu)
- [Tước hiệu không đồng nghĩa cảnh giới](#tước-hiệu-không-đồng-nghĩa-cảnh-giới)
- [Cách lập sổ xưng hô](#cách-lập-sổ-xưng-hô)

## Nguyên tắc đọc xưng hô

Không dịch đại từ trước rồi mới đoán quan hệ. Với mỗi câu, xác định bốn trục:

1. Người nói đang đứng ở đâu trong thứ bậc quyền lực?
2. Người nghe là cấp trên, cấp dưới, đồng môn, người yêu, kẻ thù hay người lạ?
3. Cảnh đang ở công khai hay riêng tư, nghi lễ hay đời thường?
4. Nhân vật đang muốn kính trọng, giữ khoảng cách, nịnh, khiêu khích, thân mật hay hạ nhục?

`我/我等/吾/本座/本尊/在下/老夫/妾身` đều có thể quy về “ta/tôi” trên bề mặt, nhưng sắc thái và địa vị khác nhau. Không chọn một đại từ tiếng Việt cố định cho cả phim nếu các dạng gốc thay đổi có chủ ý.

## Tự xưng theo thân phận

| 中文 | Gợi ý tiếng Việt | Cảnh dùng |
|---|---|---|
| 我 / 我们 | ta/tôi / chúng ta | Trung tính; phải xét bối cảnh |
| 吾 / 吾等 | ta / chúng ta | Cổ phong, nghiêm, có học hoặc có địa vị |
| 本座 | bản tọa/bổn tọa | Tự xưng nhấn mạnh quyền uy; có thể đến từ chức vị, tu vi, vị thế hoặc tính cách. Không cần có “tòa” thật và không tự chứng minh cảnh giới |
| 本尊 | bản tôn/bổn tôn | Tự xưng tôn quý hoặc cách gọi bản thể đối lập với phân thân; phải xác định đang là đại từ hay danh từ |
| 本王 / 本帝 / 本君 | bản vương/bản đế/bản quân | Chỉ dùng theo tước hiệu hoặc quy ước của tác phẩm; không tự suy ra người đó thật sự cai trị hay đạt cảnh giới tương ứng |
| 本宫 / 本殿 | bản cung/bản điện | Cung đình, chủ nhân cung/điện hoặc quy ước riêng của thế lực; nữ cường giả không tự động dùng bản cung |
| 朕 | trẫm | Hoàng đế; không dùng cho vua nhỏ nếu phim phân biệt |
| 孤 / 寡人 | quả nhân/cô vương/ta; quả nhân | Quân chủ, chư hầu hoặc nhân vật cổ phong; không ép `孤` thành “cô” đứng riêng nếu gây nhầm với đại từ tiếng Việt |
| 哀家 | ai gia | Thường là thái hậu trong quy ước kịch/phim; không tự gán cho mọi nữ nhân lớn tuổi |
| 臣妾 | thần thiếp | Phi tần/nữ tử trong cung khi nói với hoàng đế hoặc theo cách phim quy ước |
| 妾 / 妾身 | thiếp / thiếp thân | Nữ tử tự hạ mình hoặc tự xưng cổ phong |
| 奴婢 / 婢妾 | nô tỳ / tỳ thiếp | Nữ hầu, thân phận thấp hoặc tự hạ mình |
| 老夫 / 老朽 | lão phu / lão hủ | Nam nhân lớn tuổi; có thể kiêu ngạo hoặc khiêm nhường |
| 小生 | tiểu sinh | Nam tử tự xưng văn nhã, thư sinh hoặc diễn ngôn cổ phong |
| 在下 | tại hạ | Khiêm xưng giang hồ, không nhất thiết là người yếu |
| 晚辈 / 后辈 | vãn bối / hậu bối | Người thuộc thế hệ sau hoặc tự hạ mình trước tiền bối; không đồng nhất hai từ khi tác phẩm phân biệt |
| 贫道 | bần đạo | Đạo sĩ tự xưng khiêm nhường |
| 贫僧 / 老衲 | bần tăng / lão nạp | Tăng nhân; không đổi thành “ta” nếu sắc thái tu hành quan trọng |
| 小僧 / 小尼 | tiểu tăng / tiểu ni | Tăng ni trẻ hoặc tự hạ mình |
| 属下 / 下官 / 微臣 | thuộc hạ / hạ quan / vi thần | Quân vụ, quan trường, phụng sự cấp trên |
| 末将 | mạt tướng | Võ tướng tự xưng với cấp trên |
| 小的 / 小人 | tiểu nhân / kẻ hèn này | Người dưới tự hạ mình; có thể mang sắc thái nịnh hoặc gian |

Không sửa thành câu “đúng lịch sử” nếu tác phẩm đang dùng quy ước phim/web novel. Mục tiêu là nhất quán với thế giới của tác phẩm, đồng thời tránh gán nhầm thân phận.

## Gọi người khác theo quan hệ

| 中文 | Mặc định tiếng Việt | Cần kiểm tra |
|---|---|---|
| 你 / 您 | ngươi/cậu/anh/cô/bạn; ngài/người | `您` là kính trọng nhưng tiếng Việt có thể thể hiện bằng chức danh và câu nói |
| 汝 / 尔 | ngươi/ngươi đó | Cổ, bề trên hoặc văn phong tu từ; không dùng thường xuyên nếu không có dụng ý |
| 卿 / 爱卿 | khanh / ái khanh | Vua nói với bề tôi; “ái khanh” không phải cách gọi thân mật thông thường |
| 阁下 | các hạ | Đối thoại giang hồ, trang trọng hoặc đối địch |
| 尊上 | tôn thượng | Gọi cường giả/tôn chủ; có thể là danh hiệu riêng |
| 前辈 / 道友 | tiền bối / đạo hữu | Xét cấp bậc và quan hệ tu hành |
| 公子 / 姑娘 | công tử / cô nương | Gọi người trẻ, con nhà thế lực hoặc khách giang hồ |
| 殿下 / 陛下 | điện hạ / bệ hạ | Hoàng tộc/quân chủ |
| 王爷 / 世子 | vương gia / thế tử | Tước vị và người thừa kế |
| 大人 / 将军 | đại nhân / tướng quân | Quan chức, người có quyền hoặc võ tướng |
| 娘娘 / 贵妃 / 皇后 | nương nương / quý phi / hoàng hậu | Chọn theo vị trí cụ thể; không gọi mọi nữ nhân hoàng cung là nương nương |

## Sư môn và giang hồ

Phân biệt quan hệ huyết thống, quan hệ truyền thừa và quan hệ đồng môn:

- `师尊` là cách gọi kính trọng dành cho thầy/người truyền đạo; thường trang trọng hơn `师父` trong văn phong tu tiên, nhưng không tự động chứng minh người đó có cảnh giới cao hơn hoặc là người đứng đầu. `师父` cũng có thể rất kính trọng. Nếu nguyên tác dùng hai từ cho cùng một người, có thể giữ sự khác biệt; không tự đổi theo công khai/riêng tư nếu câu gốc không thể hiện điều đó.
- `师兄/师姐/师弟/师妹` là thứ bậc nhập môn, không tự suy ra tuổi tác hay quan hệ ruột thịt.
- `师伯/师叔/师姑/师祖/师母` phải đối chiếu cây sư môn; không dịch theo tuổi đời.
- `掌门/宗主/峰主/长老` là chức vụ, còn `师尊` là quan hệ thầy–trò; một người có thể đồng thời mang nhiều nhãn.
- `道侣` là bạn đồng hành/đạo lữ trong tu hành, có thể là bạn đời hoặc người yêu theo lore; không tự dịch thành “người yêu” trong mọi cảnh nhưng cũng không cấm dùng cách diễn đạt tự nhiên nếu mối quan hệ đã rõ.
- `尊者/真人/真君/道君/道尊` có thể là danh hiệu, cảnh giới hoặc cách gọi kính trọng; phải xem hệ thống tác phẩm. Không tự thêm `tôn giả` vào bản dịch nếu nguyên tác không dùng `尊者`.

## Triều đình và phủ đệ

Ghi riêng “ai nói với ai” vì cùng một nhân vật có thể đổi xưng hô giữa triều đình, gia đình và chốn riêng:

- Hoàng đế có thể dùng `朕`, `孤`, `本王` hoặc `我` tùy thân phận/lore; không ép tất cả thành “trẫm”. `本帝` thường là `bản đế`; chỉ cân nhắc `trẫm` khi tác phẩm thật sự xây dựng Tiên Đình/hoàng triều theo mô hình đế chế.
- Hoàng hậu, phi tần và công chúa có thể dùng `本宫`, `本殿`, `臣妾`, `妾`, `我`; đây là quy ước diễn ngôn, cần xét vị trí cụ thể.
- `王妃/夫人/少夫人/小姐/姑娘` không cùng một mức thân phận; giữ đúng tầng gia tộc và hôn nhân.
- `父皇/母后/皇兄/皇叔` nên dịch theo quan hệ hoàng gia, không giản lược thành ba/mẹ/anh/chú nếu làm mất nghi lễ.
- `奴才/奴婢` là tự xưng của người hầu; không dùng cho mọi thuộc hạ nam/nữ nếu tác phẩm phân biệt.

## Đạo môn, Phật môn, tiên–ma–yêu

- `道长` = đạo trưởng; `真人` có thể là chân nhân hoặc danh hiệu, không mặc định là “người thật”.
- `大师/法师/方丈/住持/佛子/圣僧` cần phân biệt đại sư, pháp sư, phương trượng, trụ trì, Phật tử, thánh tăng.
- `仙尊/魔尊/妖尊/鬼尊` thường giữ thành “Tiên Tôn/Ma Tôn/Yêu Tôn/Quỷ Tôn” nếu là danh hiệu; không dịch chung thành “tiên nhân” hay “ma vương”. Nếu chữ `尊` là cảnh giới, vẫn phải ghi nhận riêng lớp cảnh giới và lớp tôn hiệu.
- `上神/神尊/神君/帝君` có thể là Thượng Thần/Thần Tôn/Thần Quân/Đế Quân; thứ bậc, chức vụ và cảnh giới không tự suy ra giữa các phim.
- `妖王/魔王/鬼王/冥王` thường là chức vị hoặc thủ lĩnh, không luôn là cảnh giới.

## Tước hiệu không đồng nghĩa cảnh giới

Tách hai cột trong sổ thuật ngữ:

`chữ gốc | chức năng trong câu | bản dịch | có phải cấp tu luyện không?`

Ví dụ, `魔尊` có thể là “Ma Tôn” (danh hiệu của nhân vật), còn `尊级` có thể là “cấp Tôn” (phẩm cấp). `仙帝` có thể là Tiên Đế của một thế lực, hoặc một bậc cảnh giới; chỉ bản thân chữ gốc không đủ để quyết định.

## Cách lập sổ xưng hô

Mỗi nhân vật cần có ít nhất các dòng:

`Tên | thân phận | tự xưng công khai | tự xưng riêng tư | gọi cấp trên | gọi đồng cấp | gọi cấp dưới | cách gọi khi giận/yêu/phản bội`

Khi quan hệ đổi, tạo mốc thay đổi thay vì sửa ngược toàn bộ bản dịch cũ. Nếu câu gốc cố ý mơ hồ, giữ mơ hồ trong tiếng Việt hoặc ghi chú ngoài phụ đề; không tự chọn một quan hệ làm thay đổi cốt truyện.

### Ghi chú nghiên cứu

Các dạng `本宫`, `哀家`, `臣妾` trong phim cổ trang có thể là quy ước sân khấu/phim hơn là mô tả lịch sử tuyệt đối. Khi dịch, ưu tiên quy ước nội tại của tác phẩm và tính nhất quán giữa nhân vật. Đối chiếu thêm các thảo luận về tự xưng cổ trang và sự khác nhau giữa `师尊` và `师父` khi cần.
