# Bảng thuật ngữ tu tiên Trung–Việt

Đây là bộ khung tham khảo, không phải luật cứng. Mỗi phim có thể đổi thứ tự, tên gọi hoặc ý nghĩa. Khi tác phẩm đã định nghĩa riêng, ưu tiên cách dùng của tác phẩm.

## Mục lục

- [Cảnh giới và tu luyện](#cảnh-giới-và-tu-luyện)
- [Năng lượng, tâm pháp và thân thể](#năng-lượng-tâm-pháp-và-thân-thể)
- [Kiếp nạn và chiến đấu](#kiếp-nạn-và-chiến-đấu)
- [Vật phẩm, tài nguyên và nơi chốn](#vật-phẩm-tài-nguyên-và-nơi-chốn)
- [Thế lực và giới vực](#thế-lực-và-giới-vực)
- [Nhân xưng và tước vị thường gặp](#nhân-xưng-và-tước-vị-thường-gặp)
- [Bậc, tầng và nhãn chiến lực](#bậc-tầng-và-nhãn-chiến-lực)
- [Quan hệ sư môn và thân phận](#quan-hệ-sư-môn-và-thân-phận)
- [Danh hiệu quyền lực](#danh-hiệu-quyền-lực)
- [Người tu hành và mô-típ thường gặp](#người-tu-hành-và-mô-típ-thường-gặp)

## Cảnh giới và tu luyện

| 中文 | Mặc định tiếng Việt | Ghi chú |
|---|---|---|
| 修仙 / 修真 | tu tiên / tu chân | Chọn một cách gọi theo thế giới truyện; không đổi lẫn tùy tiện |
| 修士 / 修炼者 | tu sĩ / người tu luyện | `修士` không nhất thiết là “đạo sĩ” |
| 修为 | tu vi | Mức tu luyện hiện có |
| 境界 | cảnh giới | Cấp bậc tu luyện hoặc trạng thái |
| 练气 / 炼气 | Luyện Khí | Thường là cảnh giới đầu hoặc quá trình; không tự đồng nhất hai chữ trong tác phẩm có hệ thống riêng |
| 凝气 | Ngưng Khí | Có thể là cảnh giới riêng, tiểu giai đoạn hoặc hành động ngưng tụ linh khí |
| 筑基 | Trúc Cơ | Cảnh giới hoặc quá trình dựng nền móng |
| 结丹 | Kết Đan | Hành động/quá trình kết thành đan; có thể là cảnh giới |
| 金丹 | Kim Đan | Đan thể hoặc cảnh giới Kim Đan |
| 元婴 | Nguyên Anh | Cảnh giới và nguyên anh trong đan điền |
| 化神 | Hóa Thần | Cảnh giới |
| 炼虚 | Luyện Hư | Cảnh giới |
| 合体 | Hợp Thể | Cảnh giới; không tự dịch thành “hợp nhất” nếu là tên cấp |
| 大乘 | Đại Thừa | Cảnh giới trong nhiều hệ thống; không tự cố định vị trí trước/sau Độ Kiếp |
| 渡劫 / 渡劫期 | Độ Kiếp / Độ Kiếp kỳ | Quá trình, sự kiện thiên kiếp hoặc cảnh giới tùy tác phẩm |
| 婴变 | Anh Biến | Có thể là cảnh giới hoặc quá trình Nguyên Anh biến đổi |
| 问鼎 | Vấn Đỉnh | Cảnh giới riêng hoặc thành ngữ tranh bá tùy câu |
| 通天 | Thông Thiên | Cảnh giới, tước hiệu, tên công pháp hoặc mô tả năng lực tùy lore |
| 归元 | Quy Nguyên | Cảnh giới, quá trình hoặc tên công pháp tùy lore |
| 真仙 / 天仙 / 金仙 | Chân Tiên / Thiên Tiên / Kim Tiên | Giữ đúng hệ thống từng phim |
| 大罗金仙 | Đại La Kim Tiên | Không rút thành “tiên cấp cao” |
| 飞升 | phi thăng | Đột phá/đi lên thượng giới hoặc tiên giới |
| 突破 | đột phá | Vượt qua bình cảnh/cảnh giới |
| 闭关 | bế quan | Tu luyện kín trong thời gian dài |
| 走火入魔 | tẩu hỏa nhập ma | Không chỉ dịch là “phát điên” |

## Năng lượng, tâm pháp và thân thể

| 中文 | Mặc định tiếng Việt |
|---|---|
| 灵气 | linh khí |
| 真气 | chân khí |
| 灵力 | linh lực |
| 法力 | pháp lực | Năng lượng pháp thuật/tu luyện có thể hao tổn; không mặc định là năng lượng bẩm sinh |
| 元力 | nguyên lực |
| 神识 | thần thức |
| 元神 | nguyên thần |
| 丹田 | đan điền |
| 经脉 | kinh mạch |
| 灵根 | linh căn |
| 道心 | đạo tâm |
| 心魔 | tâm ma |
| 因果 | nhân quả |
| 业力 | nghiệp lực |
| 天道 | thiên đạo |
| 大道 | đại đạo |
| 法则 | pháp tắc |
| 意境 | ý cảnh |
| 领域 | lĩnh vực |
| 功法 | công pháp |
| 心法 | tâm pháp |
| 口诀 | khẩu quyết |
| 神通 | thần thông |
| 秘术 | bí thuật |
| 本命 | bản mệnh |
| 仙力 | tiên lực |
| 魔力 | ma lực | Giữ theo hệ thống năng lượng của phim; không tự đổi thành “ma pháp” |
| 妖力 | yêu lực |
| 大能 | đại năng | Cường giả/nhân vật có năng lực lớn, không mặc định là một cảnh giới |
| 仙人 | tiên nhân |
| 凡人 | phàm nhân |
| 魔修 | ma tu |
| 妖修 | yêu tu |

## Kiếp nạn và chiến đấu

| 中文 | Mặc định tiếng Việt |
|---|---|
| 天劫 | thiên kiếp |
| 雷劫 | lôi kiếp |
| 心魔劫 | tâm ma kiếp |
| 雷罚 | lôi phạt |
| 神通 | thần thông |
| 剑意 | kiếm ý |
| 剑阵 | kiếm trận |
| 阵法 | trận pháp |
| 禁制 | cấm chế |
| 封印 | phong ấn |
| 结界 | kết giới |
| 符箓 | phù lục |
| 术法 / 法术 | thuật pháp / pháp thuật |
| 杀招 | sát chiêu |
| 杀意 | sát ý |
| 威压 | uy áp |
| 反噬 | phản phệ |
| 夺舍 | đoạt xá |
| 自爆 | tự bạo |

## Vật phẩm, tài nguyên và nơi chốn

| 中文 | Mặc định tiếng Việt |
|---|---|
| 法器 | pháp khí |
| 灵器 | linh khí (vật phẩm) | Phân biệt với `灵气` = linh khí (năng lượng); khóa cách ghi theo lore của phim |
| 法宝 | pháp bảo |
| 灵宝 | linh bảo |
| 仙器 | tiên khí |
| 本命法宝 | bản mệnh pháp bảo |
| 丹药 | đan dược |
| 灵石 | linh thạch |
| 灵脉 | linh mạch |
| 洞府 | động phủ | Nơi ở hoặc không gian tu luyện riêng; không nhất thiết là hang động |
| 洞天 | động thiên | Không gian có nội cảnh hoặc không gian tu luyện đặc biệt; không tự đồng nhất với động phủ |
| 福地 | phúc địa | Vùng đất/phúc địa có linh khí hoặc cơ duyên đặc biệt |
| 储物袋 | túi trữ vật |
| 纳戒 | nạp giới |
| 乾坤袋 | túi càn khôn |
| 秘境 | bí cảnh |
| 遗迹 | di tích |
| 传承 | truyền thừa |
| 血脉 | huyết mạch |
| 契约 | khế ước |
| 认主 | nhận chủ |

## Thế lực và giới vực

| 中文 | Mặc định tiếng Việt |
|---|---|
| 宗门 | tông môn |
| 门派 | môn phái |
| 仙门 | tiên môn |
| 魔门 | ma môn |
| 圣地 | thánh địa |
| 世家 | thế gia |
| 皇朝 | hoàng triều |
| 长老 | trưởng lão |
| 掌门 | chưởng môn |
| 宗主 | tông chủ |
| 太上长老 | thái thượng trưởng lão |
| 峰主 | phong chủ |
| 妖族 | yêu tộc |
| 魔族 | ma tộc |
| 鬼族 | quỷ tộc |
| 灵兽 | linh thú |
| 界海 | giới hải | Không gian/biển giữa các giới hoặc tên riêng; không mặc định là biển nước |
| 鬼界 / 冥界 | quỷ giới / minh giới | Có thể tách hoặc gộp theo lore; không tự coi Minh Giới chỉ là cơ quan luân hồi |
| 仙界 | tiên giới |
| 魔界 | ma giới |
| 冥界 | minh giới |
| 凡界 | phàm giới |
| 上界 / 下界 | thượng giới / hạ giới |
| 人界 | nhân giới |

## Nhân xưng và tước vị thường gặp

| 中文 | Mặc định tiếng Việt |
|---|---|
| 师尊 | sư tôn |
| 师父 | sư phụ |
| 师兄 / 师姐 | sư huynh / sư tỷ |
| 师弟 / 师妹 | sư đệ / sư muội |
| 道友 | đạo hữu |
| 前辈 / 后辈 | tiền bối / hậu bối |
| 在下 / 本座 | tại hạ / bổn tọa |
| 本王 / 本宫 | bổn vương / bổn cung |
| 殿下 / 陛下 | điện hạ / bệ hạ |
| 王爷 / 娘娘 | vương gia / nương nương |
| 公子 / 姑娘 | công tử / cô nương |
| 夫君 / 夫人 | phu quân / phu nhân |
| 大人 | đại nhân |

## Người tu hành và mô-típ thường gặp

| 中文 | Mặc định tiếng Việt | Ghi chú |
|---|---|---|
| 仙子 | tiên tử | Có thể là danh xưng lịch sự dành cho nữ tu, không nhất thiết là tiên nhân chính thức |
| 大侠 | đại hiệp | Danh xưng giang hồ; không tự dịch thành “anh hùng” nếu đang giữ màu võ hiệp |
| 转世 | chuyển thế | Có thể là tái sinh/chuyển sinh theo lore; không luôn đồng nghĩa với `重生` |
| 重生 | trùng sinh | Sống lại/quay về một thời điểm khác; phân biệt với chuyển thế nếu phim phân biệt |
| 逆天改命 | nghịch thiên cải mệnh | Cụm motif; có thể Việt hóa tự nhiên trong lời thoại nhưng giữ ý chống lại số mệnh |
| 三生三世 | tam sinh tam thế | Cụm điển cố/motif về nhiều kiếp; không tự diễn giải thành “ba đời ba kiếp” nếu tên tác phẩm đã khóa |

## Bậc, tầng và nhãn chiến lực

| 中文 | Mặc định tiếng Việt | Cách xử lý |
|---|---|---|
| 初期 / 中期 / 后期 | sơ kỳ / trung kỳ / hậu kỳ | Dùng khi là tiểu cảnh giới; không tự đổi thành đầu/giữa/cuối nếu hệ thống đã dùng Hán–Việt |
| 巅峰 | đỉnh phong | Có thể là trạng thái gần đột phá, không mặc định là cảnh giới riêng |
| 圆满 / 大圆满 | viên mãn / đại viên mãn | Giữ phân biệt nếu cả hai cùng xuất hiện |
| 半步 | bán bộ | `半步化神` = bán bộ Hóa Thần; không dịch thành “nửa bước” trong bản phụ đề nghiêm túc |
| 伪境 / 伪仙 | ngụy cảnh / ngụy tiên | Không mặc định là giả tạo; thường chỉ trạng thái chưa đạt chuẩn |
| 准帝 / 准圣 | chuẩn đế / chuẩn thánh | Cấp kề trước danh hiệu tương ứng |
| 一重 / 九重 | nhất trọng / cửu trọng | Giữ số tầng; chỉ dùng “tầng một/tầng chín” nếu phong cách bản dịch yêu cầu |
| 一层 / 十三层 | tầng một / tầng mười ba | Không trộn với `重` nếu phim phân biệt cách đếm |
| 一品 / 九品 | nhất phẩm / cửu phẩm | Có thể là phẩm chất đan dược, trận pháp, luyện khí hoặc cảnh giới |
| 一阶 / 九阶 | nhất giai / cửu giai | Có thể là cấp vật phẩm, linh thú, ma thú hoặc tu vi |
| 一重 / 九重 | nhất trùng / cửu trùng | Cấp nhỏ trong cảnh giới hoặc hệ thống riêng; không đổi thành “tầng” nếu phim phân biệt |
| 天地玄黄 | Thiên–Địa–Huyền–Hoàng | Thường là phẩm cấp công pháp/vật phẩm; không tự xem là cảnh giới |
| 王级 / 皇级 / 帝级 | cấp Vương / cấp Hoàng / cấp Đế | Dùng theo lore; chữ `级` có thể là phẩm cấp hoặc chiến lực |
| 圣级 / 尊级 / 神级 | cấp Thánh / cấp Tôn / cấp Thần | Không suy ra thứ tự tuyệt đối nếu phim chưa xác nhận |

## Danh hiệu quyền lực

| 中文 | Mặc định tiếng Việt | Ghi chú |
|---|---|---|
| 仙尊 / 魔尊 / 妖尊 / 鬼尊 | Tiên Tôn / Ma Tôn / Yêu Tôn / Quỷ Tôn | Có thể là tước hiệu, chức vụ hoặc cảnh giới; không tự suy ra thứ bậc |
| 帝君 | Đế Quân | Chức vị/tước hiệu/cảnh giới tùy tác phẩm; không dịch thành “hoàng đế quân chủ” |
| 上神 / 神尊 / 神君 | Thượng Thần / Thần Tôn / Thần Quân | Không tự gộp với tiên nhân hoặc thần giới |
| 真君 / 真人 | Chân Quân / Chân Nhân | Tôn hiệu, chức danh, đạo hiệu hoặc cảnh giới tùy lore |
| 尊者 | Tôn giả | Chỉ dùng khi nguyên tác thật sự gọi như vậy; không tự thêm cho mọi cường giả |
| 圣主 / 教主 / 掌门 / 宗主 | Thánh Chủ / Giáo Chủ / Chưởng Môn / Tông Chủ | Chức vụ tổ chức, không mặc định là cảnh giới |

## Quan hệ sư môn và thân phận

| 中文 | Mặc định tiếng Việt |
|---|---|
| 师伯 / 师叔 / 师姑 | sư bá / sư thúc / sư cô |
| 师祖 / 师母 / 祖师 | sư tổ / sư mẫu / tổ sư |
| 道侣 | đạo lữ |
| 双修 | song tu |
| 炉鼎 | lô đỉnh |
| 护道者 | hộ đạo giả / người hộ đạo |
| 契约兽 / 灵宠 / 坐骑 | khế ước thú / linh sủng / tọa kỵ |
| 亲传弟子 | đệ tử thân truyền |
| 嫡传弟子 | đệ tử đích truyền |
| 内门弟子 / 外门弟子 | đệ tử nội môn / đệ tử ngoại môn |
| 杂役弟子 | đệ tử tạp dịch |
| 少主 / 少宗主 | thiếu chủ / thiếu tông chủ |
| 圣子 / 圣女 | thánh tử / thánh nữ |
| 传人 / 继承人 | truyền nhân / người kế thừa |

### Quy tắc dùng bảng

1. Ghi chữ Hán và cách đọc đã chọn vào sổ thuật ngữ ngay lần đầu gặp.
2. Phân biệt từ là **tên cảnh giới**, **vật thể**, **động tác** hay **tước vị** trước khi dịch.
3. Nếu hai thuật ngữ khác chữ nhưng cùng nghĩa bề mặt, vẫn giữ khác nhau nếu lore phân biệt.
4. Không dịch `道` thành “đạo” một cách máy móc trong mọi câu; có thể là đạo lý, con đường, pháp tắc hoặc Đạo theo nghĩa siêu hình.
