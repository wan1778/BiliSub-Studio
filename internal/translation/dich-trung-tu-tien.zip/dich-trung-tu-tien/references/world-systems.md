# Hệ thống cảnh giới, giới vực và khu vực đặc biệt

## Mục lục

- [Bốn lớp cần tách](#bốn-lớp-cần-tách)
- [Cảnh giới lớn và nhỏ](#cảnh-giới-lớn-và-nhỏ)
- [Cấp phẩm và cấp chiến lực](#cấp-phẩm-và-cấp-chiến-lực)
- [Giới vực và thế giới](#giới-vực-và-thế-giới)
- [Khu vực đặc biệt](#khu-vực-đặc-biệt)
- [Tiên, thần, ma, yêu, quỷ, linh](#tiên-thần-ma-yêu-quỷ-linh)
- [Bộ kiểm tra trước khi dịch](#bộ-kiểm-tra-trước-khi-dịch)

## Bốn lớp cần tách

Không gom tất cả từ chỉ sức mạnh thành “cảnh giới”. Tạo bốn cột:

1. **Đại cảnh giới**: Luyện Khí, Trúc Cơ, Kim Đan, Nguyên Anh… hoặc hệ thống riêng của phim.
2. **Tiểu cảnh giới**: sơ kỳ, trung kỳ, hậu kỳ, đỉnh phong, viên mãn, đại viên mãn.
3. **Cấp phẩm/cấp tầng**: nhất phẩm, cửu phẩm, nhất giai, cửu giai, nhất trọng, cửu trọng, tầng một, tầng mười ba.
4. **Danh hiệu/chiến lực**: Tiên Tôn, Ma Tôn, Đế Quân, Thánh Chủ, bán bộ Tiên Đế, chuẩn Thánh.

Một câu có thể chứa nhiều lớp: `化神后期巅峰` = “đỉnh phong Hóa Thần hậu kỳ” hoặc cách diễn đạt tự nhiên theo bản dịch đã khóa. Không bỏ `后期` chỉ vì đã có `巅峰`.

## Cảnh giới lớn và nhỏ

Khung thường gặp gồm `炼气/练气`, `筑基`, `结丹/金丹`, `元婴`, `化神`, `炼虚`, `合体`, `大乘`, `渡劫`, rồi đến các bậc tiên/thần riêng. Đây chỉ là mẫu tham chiếu, không phải thứ tự bắt buộc; nhiều tác phẩm dùng `凝气`, `婴变`, `问鼎`, `通天`, `圣境`, `帝境` hoặc hệ thống hoàn toàn khác. Đặc biệt không tự suy ra quan hệ giữa `大乘` và `渡劫`: trong nhiều hệ thống Đại Thừa đứng trước Độ Kiếp, nhưng tác phẩm có thể quy ước khác.

Quy tắc:

- Ghi cả chữ Hán gốc và âm Hán–Việt đã chọn.
- Ghi rõ từ đó là tên cảnh giới, hành động đột phá, trạng thái hay vật thể.
- Không dịch `结丹` và `金丹` như nhau nếu câu đang phân biệt quá trình với đan thể/cảnh giới.
- Không tự thêm “kỳ”, “cảnh”, “cấp” vào mọi dòng; chọn một kiểu nhất quán theo cách tác phẩm gọi.
- Nếu hệ thống dùng số tầng, giữ đúng số tầng và không suy ra số tầng tối đa từ tác phẩm khác.

## Cấp phẩm và cấp chiến lực

Các nhãn sau thường có nhiều nghĩa:

| Nhóm | Ví dụ | Cách dịch mặc định |
|---|---|---|
| Tầng | 一重、九重 | nhất trọng, cửu trọng |
| Tầng học/tu luyện | 一层、十三层 | tầng một, tầng mười ba; không chỉ dùng cho Luyện Khí |
| Phẩm | 一品、九品 | nhất phẩm, cửu phẩm; có thể là vật phẩm, huyết mạch hoặc cảnh giới |
| Giai | 一阶、九阶 | nhất giai, cửu giai; có thể là vật phẩm, linh thú, trận pháp hoặc tu vi |
| Phẩm chất | 天阶、地阶、玄阶、黄阶 | Thiên giai, Địa giai, Huyền giai, Hoàng giai |
| Chuẩn bị đạt cấp | 半步、准 | bán bộ, chuẩn |
| Chưa đủ chuẩn | 伪、伪境 | ngụy, ngụy cảnh |
| Trạng thái đỉnh | 巅峰、圆满、大圆满 | đỉnh phong, viên mãn, đại viên mãn |

`天地玄黄` không phải lúc nào cũng là thứ tự sức mạnh tuyệt đối; `天阶功法` thường là phẩm cấp công pháp, không phải “cảnh giới Thiên”. `帝级`, `尊级`, `神级` cũng có thể là cấp vật phẩm, huyết mạch, trận pháp hoặc chiến lực.

Không cấm `一品`, `一阶` hoặc `一层` xuất hiện trong hệ thống tu vi: một số tác phẩm dùng chúng cho cảnh giới hoặc cấp nhân vật. `天地玄黄` cũng có thể được mở rộng sang huyết mạch hay hệ thống khác. Chỉ kết luận đối tượng mà cấp bậc đang bổ nghĩa sau khi xem câu đầy đủ và các lần dùng lặp lại.

Các hậu tố là dấu hiệu gợi ý, không phải quy tắc ngữ pháp tuyệt đối. Một tác phẩm có thể dùng `域` như tên một đại thế giới, `宫` như thế lực, `府` như tổ chức hoặc `天` như tên nhân vật/địa danh. Chỉ khóa cách dịch sau khi xem câu định nghĩa, bản đồ thế giới hoặc các lần dùng lặp lại.

## Giới vực và thế giới

| 中文 | Mặc định tiếng Việt | Phải kiểm tra |
|---|---|---|
| 人界 / 凡界 | nhân giới / phàm giới | Hai từ có thể đồng nghĩa hoặc là hai tầng khác nhau |
| 仙界 / 神界 | tiên giới / thần giới | Có phim tách tiên và thần, có phim gộp |
| 魔界 / 妖界 / 鬼界 / 冥界 | ma giới / yêu giới / quỷ giới / minh giới | Không gom thành một “giới ác” |
| 上界 / 下界 | thượng giới / hạ giới | Có thể là tầng không gian hoặc khu vực chính trị |
| 诸天万界 | chư thiên vạn giới | Cụm chỉ vô số thế giới, không phải tên một địa điểm đơn lẻ |
| 界域 | giới vực | Một vùng/thế lực/miền không gian tùy lore |
| 界海 | giới hải | Thường là không gian/biển giữa các giới; có thể là biển thật nếu lore xác nhận |
| 天外天 | Thiên Ngoại Thiên | Khu vực đặc biệt hoặc tầng trời ngoài hệ thống thường |
| 九重天 | Cửu Trùng Thiên / chín tầng trời | Có thể là cấu trúc chín tầng, nhiều thiên giới hoặc tên riêng; chọn theo mô tả tác phẩm |
| 虚空 | hư không | Không gian trống/ngoài giới; không luôn là “vũ trụ” |
| 混沌海 | Hỗn Độn Hải | Vùng hỗn độn; giữ sắc thái địa danh nếu phim dùng như tên riêng |

Đừng đổi `界` thành “cõi”, “giới”, “thế giới” theo cảm tính trong cùng một tác phẩm. Chọn một quy ước sau khi xác định cấu trúc không gian.

## Khu vực đặc biệt

| 中文 | Mặc định tiếng Việt | Phân biệt |
|---|---|---|
| 秘境 | bí cảnh | Khu vực/không gian bí mật có thể vào bằng điều kiện riêng |
| 禁地 | cấm địa | Vùng bị cấm, bị kiêng kỵ hoặc cực kỳ nguy hiểm; lệnh cấm có thể do tổ chức hoặc do lore tự nhiên |
| 绝地 | tuyệt địa | Vùng cực kỳ nguy hiểm/gần như không có đường sống; không mặc định chắc chắn chết |
| 圣地 | thánh địa | Khu vực hoặc thế lực được tôn kính; không nhất thiết là nơi tu luyện |
| 遗迹 | di tích | Dấu tích của nền văn minh, cường giả hoặc thời đại cũ |
| 古战场 | cổ chiến trường | Vùng chiến tranh cổ, thường có sát khí/truyền thừa |
| 神墓 / 帝陵 | thần mộ / đế lăng | Mộ của thần/đế; giữ sắc thái địa danh |
| 洞府 | động phủ | Nơi ở/động phủ tu luyện riêng; không nhất thiết là hang động |
| 洞天 / 福地 | động thiên / phúc địa | Động thiên có thể là không gian có nội cảnh; phúc địa là vùng đất linh khí đặc biệt; không tự thay thế nhau |
| 洞天福地 | động thiên phúc địa | Cụm cố định; không dịch thành “hang động may mắn” |
| 小世界 | tiểu thế giới | Thế giới nhỏ độc lập hoặc không gian trong bảo vật |
| 领域 | lĩnh vực / khu vực / lãnh địa | Có thể là năng lực, phạm vi khống chế hoặc khu vực địa lý; không mặc định là một loại địa danh |
| 禁区 | khu cấm / cấm khu | Vùng bị phong tỏa, nguy hiểm hoặc có thế lực cấm kỵ |
| 传承地 | nơi truyền thừa | Nơi nhận truyền thừa, không nhất thiết là di tích |
| 试炼场 | nơi thí luyện | Khu vực kiểm tra/huấn luyện |

Các cụm `荒古禁地`, `葬仙地`, `轮回海`, `黄泉`, `忘川`, `彼岸` thường là tên riêng giàu điển cố. Dịch theo lore và chú ý viết hoa/viết thường nhất quán, không biến thành danh từ đời thường nếu đó là tên của một vùng cụ thể. `试炼场` thường là “nơi/trường thí luyện”; chỉ dùng “đấu trường” khi thật sự có thi đấu.

`绝地` mô tả mức nguy hiểm, không phải lời cam kết mọi người chắc chắn chết. `禁地` có thể do luật lệ, điều cấm kỵ, sự linh thiêng hoặc nguy hiểm tự nhiên. `洞府` không nhất thiết là hang động, `洞天` không nhất thiết là một thế giới hoàn chỉnh, và `界域` có thể là khu vực trong thế giới hoặc một miền không gian lớn tùy lore.

## Tiên, thần, ma, yêu, quỷ, linh

Phân tích `妖/魔/鬼/灵/神/仙` theo ba khả năng:

1. **Chủng tộc**: yêu tộc, ma tộc, quỷ tộc, linh tộc.
2. **Giới vực/phe phái**: ma giới, tiên môn, thần đình.
3. **Trạng thái hoặc danh hiệu**: thành tiên, nhập ma, yêu hóa, linh thể, Ma Tôn.

`妖` không luôn là “quái vật”; có thể là yêu tộc có xã hội và nhân cách. `魔` không luôn là “ác quỷ”; có thể là một hệ thống tu luyện hoặc phe đối lập. `鬼` có thể là linh hồn, quỷ tộc hoặc cư dân minh giới. Trong tiếng Việt, `ma` có thể gợi “ma quỷ” nhưng cũng là âm Hán–Việt quen thuộc trong `ma tu`, `ma giới`, `ma tôn`; không thay chữ `魔` thành “ma” hoặc “ác quỷ” theo một công thức duy nhất. Chỉ chọn “yêu quái/ma quỷ” khi tiếng Việt và lore cùng yêu cầu.

## Bộ kiểm tra trước khi dịch

Trước khi dịch một đoạn có worldbuilding, trả lời:

- Đây là cấp tu luyện, cấp phẩm, danh hiệu hay chức vụ?
- Từ này chỉ người, vật, trạng thái, giới vực hay địa điểm?
- Khu vực này thuộc tầng không gian nào và có điều kiện ra vào gì?
- `界`, `境`, `域`, `地`, `海`, `天`, `宫`, `殿`, `府`, `门` đang là hậu tố địa danh hay danh từ chung?
- Nhân vật dùng danh hiệu để tự xưng, được người khác gọi, hay đang nói về một cảnh giới?
- Tác phẩm đã dùng cách dịch nào trước đó chưa?

Nếu chưa đủ bằng chứng, giữ cách dịch trung tính và ghi chú cần xác nhận. Không tự dựng thứ bậc giữa các giới vực hoặc cảnh giới chỉ vì thấy quen từ tác phẩm khác.

### Cơ sở đối chiếu

Khung cảnh giới phổ biến và biến thể được đối chiếu từ các tài liệu thảo luận về tu tiên và hướng dẫn sáng tác Trung Quốc; cấu trúc sáu giới chỉ là một mô hình tham khảo, không phải chuẩn chung. Có thể xem thêm [bài giới thiệu hệ thống tu luyện hiện đại](https://author.17k.com/ck/author/article/content/43.html), [tổng hợp cảnh giới tu tiên](https://zhuanlan.zhihu.com/p/613252839), [mô hình sáu giới của một IP tiên hiệp](https://pal.softstar.com.tw/pal3/info_world_02.asp), và [tổng quan cảnh giới từ Tencent Anime](https://m.ac.qq.com/Ask/detail/aid/petudyqbwz).
