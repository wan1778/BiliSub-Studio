# Quy tắc thẩm định nghiên cứu và dữ liệu từ AI

## Mục đích

AI Trung, từ điển, bài giải thích thuật ngữ và bảng nghiên cứu bên ngoài rất hữu ích để mở rộng danh sách ứng viên, nhưng không được xem là luật chung của mọi phim. Khi nhận một bảng thuật ngữ, hãy tách **thông tin có thể dùng**, **nhận định cần kiểm tra** và **ví dụ dịch cần sửa**.

## Thứ tự ưu tiên bằng chứng

Ưu tiên theo thứ tự:

1. Câu thoại, phụ đề chính thức, lời giải thích hoặc bản đồ xuất hiện trong chính tác phẩm.
2. Cách gọi lặp lại của cùng nhân vật, tông môn, triều đình hoặc giới vực trong toàn bộ file.
3. Tài liệu chính thức của tác phẩm, tác giả, nhà phát hành hoặc wiki chính thức.
4. Từ điển tiếng Trung và tài liệu Hán–Việt để xác định nghĩa nền.
5. Quy ước phổ biến của tiểu thuyết/phim tiên hiệp và các bảng thuật ngữ cộng đồng.
6. Câu trả lời của AI, chỉ dùng như nguồn gợi ý và phản biện, không dùng để tự áp đặt hệ thống.

## Các kết luận hữu ích từ nghiên cứu AI Trung

- Phân tích xưng hô theo người nói, người nghe, địa vị, cảnh công khai/riêng tư và cảm xúc.
- Phân biệt quan hệ nhập môn với tuổi tác: `师兄/师姐` thường liên quan đến thứ tự vào môn, nhưng phải theo lore.
- Tách đại cảnh giới, tiểu cảnh giới, cấp phẩm/cấp tầng và tước hiệu/chiến lực.
- Xem `仙尊/魔尊/帝君/神尊/上神/道君/真人/尊者` là nhóm đa nghĩa; không tự kết luận là cảnh giới, chức vụ hay kính xưng.
- Phân biệt `秘境`, `禁地`, `圣地`, `遗迹`, `洞天福地`, `界域`, `界海`, `九重天` và `混沌海` theo chức năng trong câu chuyện.
- Phân biệt `仙/神/魔/妖/鬼/灵` là chủng tộc, phe phái, trạng thái, thuộc tính sức mạnh hoặc danh hiệu.
- Giữ `道侣`, `双修`, `炉鼎` theo ngữ cảnh; không tự làm nhẹ, lãng mạn hóa hoặc tình dục hóa khi nguyên tác chưa xác nhận.

## Nghĩa nền và nghĩa trong web novel

Không trộn nghĩa từ điển với nghĩa quy ước của tiên hiệp:

- `本座` trong từ điển có nghĩa nền liên quan đến “chỗ/ngai vị vốn có”; trong web novel, nó phát triển thành lối tự xưng nhấn mạnh người nói đang nắm một vị trí hoặc quyền lực. Vì vậy bản dịch phải xét người nói và thế lực, không coi `本座` là đại từ lịch sử dùng cho mọi cường giả.
- `本尊` có lớp nghĩa tôn giáo là “bản tôn/hộ pháp thần” và trong văn học tu tiên còn có thể chỉ bản thể đối lập với phân thân. Không mặc định mọi `本尊` đều chỉ cấp cao nhất.
- `道侣` trong nghĩa nền là bạn đồng hành cùng tu hành; trong web novel có thể mở rộng thành bạn đời, người yêu hoặc bạn đồng hành tu đạo. Chỉ chọn “đạo lữ”, “bạn đạo”, “phu thê” hay “người yêu” sau khi xem quan hệ trong tác phẩm.
- `魔尊` trong từng IP có thể là thủ lĩnh, tước hiệu, nhân vật mạnh nhất của ma tộc, hoặc một cấp cảnh giới. Không lấy thứ bậc của IP này áp sang IP khác.

Nguồn đối chiếu: [Hán Điển – 本座](https://zdic.net/hans/%E6%9C%AC%E5%BA%A7), [Hán Điển – 本尊](https://zdic.net/hans/%E6%9C%AC%E5%B0%8A), [Hán Điển – 道侣](https://zdic.net/hans/%E9%81%93%E4%BE%A3), [中国作家网 về sự hình thành các hệ thống tu chân hiện đại](https://www.chinawriter.com.cn/n1/2020/0113/c425784-31546542.html), và [tư liệu IP về mô hình sáu giới](https://pal.softstar.com.tw/pal3/info_world_02.asp).

## Các nhận định không được nhập nguyên văn thành luật

### 1. `师尊` luôn cao hơn `师父`

Không đúng tuyệt đối. `师尊` là kính xưng dành cho thầy/người truyền đạo; thường trang trọng hơn trong văn phong tu tiên, nhưng không tự động chứng minh người đó có cảnh giới cao hơn. `师父` cũng có thể rất kính trọng. Từ điển [Hán Điển](https://zdic.net/hans/%E5%B8%88%E5%B0%8A) định nghĩa `师尊` trước hết là cách gọi kính trọng dành cho thầy, không phải một cấp tu luyện cố định.

### 2. `仙尊`, `魔尊`, `帝君` luôn là cảnh giới hoặc luôn là chức vụ

Không đúng tuyệt đối. Tách ba lớp: tên người/tôn hiệu, chức vụ trong thế lực, và cảnh giới nếu tác phẩm có định nghĩa. Một nhân vật có thể được gọi là `魔尊` vì là thủ lĩnh, còn tác phẩm khác dùng `魔尊境` như một cảnh giới.

### 3. `一品/九品` chỉ là cấp đan dược/pháp bảo

Không đủ. Nó có thể là phẩm cấp luyện đan, luyện khí, trận pháp, công pháp, huyết mạch, nhân vật hoặc cảnh giới. Ghi đối tượng mà cấp phẩm đang bổ nghĩa.

### 4. Hậu tố `界/域/地/海/天/宫/殿/府/门` luôn có một nghĩa cố định

Không đủ. Đây chỉ là dấu hiệu gợi ý. Tác phẩm có thể đặt tên thế lực bằng `宫`, đặt tên thế giới bằng `域`, hoặc dùng `天` như một địa danh. Cần xem cấu trúc thế giới và cách dùng lặp lại.

### 5. `魔` luôn là ma quỷ và `鬼` luôn là hồn ma

Không đúng. Trong tiếng Việt, giữ âm Hán–Việt trong `ma tu`, `ma giới`, `ma tôn` thường rõ hơn dịch thành “ác quỷ”. Với `鬼`, chọn “quỷ”, “hồn ma”, “minh tộc” hoặc cách khác tùy lore.

### 6. Tất cả bản dịch ví dụ của AI đều có thể dùng làm phụ đề

Không đúng. Ví dụ AI có thể đúng nghĩa nhưng cứng, sai dấu, sai sắc thái hoặc không hợp voice. Phải kiểm âm và kiểm xưng hô lại. Đặc biệt không bê nguyên các câu cổ văn quá đặc, câu chửi hiện đại hoặc câu dùng `mày/tao` nếu cảnh không cho phép.

## Mẫu sổ thẩm định thuật ngữ

```text
中文:
Pinyin:
Nghĩa nền:
Lần xuất hiện đầu:
Nhân vật dùng:
Đối tượng được gọi:
Chức năng: [ ] cảnh giới [ ] tiểu cảnh giới [ ] phẩm cấp [ ] tước hiệu [ ] chức vụ [ ] giới vực [ ] địa điểm [ ] chủng tộc [ ] trạng thái [ ] vật thể
Cách dùng đã xác nhận trong phim:
Bản dịch tiếng Việt khóa:
Biến thể được phép:
Không được dịch thành:
Mức độ chắc chắn: [ ] xác nhận từ phim [ ] suy ra nhiều câu [ ] quy ước thể loại [ ] chưa chắc
Ghi chú quan hệ/lore:
```

## Mẫu sổ xưng hô theo nhân vật

```text
Tên nhân vật:
Thân phận và cảnh giới:
Tự xưng trước công chúng:
Tự xưng khi nói riêng:
Gọi sư tôn/cấp trên:
Gọi đồng môn:
Gọi cấp dưới:
Gọi người yêu/đạo lữ:
Khi tức giận:
Khi bị thương hoặc hấp hối:
Khi quan hệ thay đổi:
```

## Kiểm tra dữ liệu AI trước khi nhập vào skill

1. Đánh dấu câu nào nói “thường”, “có thể” và câu nào khẳng định tuyệt đối.
2. Loại bỏ mọi thứ bậc cảnh giới không có nguồn tác phẩm cụ thể.
3. Kiểm tra lại từng ví dụ tiếng Việt về dấu, âm Hán–Việt, nhịp nói và quan hệ nhân vật.
4. Tách ví dụ “cổ văn” khỏi bản dịch phụ đề tự nhiên; không dùng bản cổ văn làm mặc định.
5. Không đưa các tên tác phẩm cụ thể vào quy tắc chung nếu chỉ đúng cho tác phẩm đó.
6. Sau khi khóa glossary, thử dịch một đoạn có chuyển xưng hô, chuyển cảnh giới và chuyển giới vực để kiểm tra tính nhất quán.

## Các điểm phải loại khỏi bảng nghiên cứu nếu gặp

- Không ghi `大乘` luôn đứng sau `渡劫`; trong nhiều hệ thống thường gặp là Đại Thừa trước Độ Kiếp, nhưng thứ tự cuối cùng vẫn phải lấy từ tác phẩm.
- Không ghi `一品`, `一阶` hoặc `一层` chỉ dùng cho đan dược, pháp bảo hay Luyện Khí. Chúng có thể là cảnh giới/cấp nhân vật trong một số tác phẩm.
- Không ghi `法力` là năng lượng tiên thiên; đó thường là năng lượng pháp thuật/tu luyện có thể tiêu hao.
- Không ghi `绝地` là nơi chắc chắn chết, `禁地` luôn do con người đặt lệnh cấm, hoặc `界海` luôn/không bao giờ là biển thật.
- Không ghi `洞府` luôn là hang động, `洞天` luôn là tiểu thế giới hoàn chỉnh, hay `冥界` chỉ là cơ quan quản lý luân hồi.
- Không dùng chuỗi cảnh giới của một tác phẩm làm bằng chứng nhận diện hệ thống của tác phẩm khác. `Kim Đan → Nguyên Anh → Hóa Thần` là mô hình phổ biến, không phải dấu hiệu thuộc riêng một IP.
- Không đưa `[CẦN XÁC NHẬN]` vào SRT thành phẩm; đó là trạng thái trong sổ nội bộ. Chỉ thêm chú thích ra phụ đề khi người dùng yêu cầu.

## Mẫu hồ sơ xác nhận cảnh giới/giới vực

```text
Từ gốc:
Câu xuất hiện:
Loại tạm thời: [ ] cảnh giới [ ] quá trình [ ] trạng thái [ ] tước hiệu [ ] chức vụ [ ] vật thể [ ] địa điểm [ ] giới vực [ ] chủng tộc
Thứ tự/cấp liên quan đã thấy:
Đối tượng mà từ đang bổ nghĩa:
Bản dịch nền:
Bản dịch khóa cho tác phẩm:
Bằng chứng: [ ] lời thoại [ ] phụ đề chính thức [ ] bản đồ/giới thiệu [ ] dùng lặp lại [ ] quy ước thể loại
Mức chắc chắn: cao / vừa / thấp
Ngoại lệ hoặc cách dùng khác:
```
